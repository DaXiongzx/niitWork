package ZhangXiao.niit.day01;

public class Circle {
	private Point point;
	private double r;
	private final double pi = 3.14;
	

	public Circle(Point point, double r) {
		this.point = point;
		this.r = r;
	}

	public double area() {
		return ((this.r*this.r)*pi);
	}
	
	public boolean contains(Point point) {
		double deltaX = this.point.getX()-point.getX();
		double deltaY = this.point.getY()-point.getY();
		double deltaX2 = deltaX*deltaX;
		double deltaY2 = deltaY*deltaY;
		double distance = deltaX2+deltaY2;
		double r2 = r*r;
		return r2>distance? true:false;
	}
}
