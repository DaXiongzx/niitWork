package ZhangXiao.niit.day04;

import java.util.Scanner;

public class Point {
	private double x;
	private double y;
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}
	public static Point parse(String location) {
		String []strArray = location.split("\\s+");
		String str1 = strArray[0].replaceAll(" +", "");
		String str2 = strArray[1].replaceAll(" +", "");
		String reg = "^[-,+]?\\d+(\\.\\d+)?$";
		if(str1.matches(reg)&&str2.matches(reg)) {
			double num1 = Double.parseDouble(str1);
			double num2 = Double.parseDouble(str2);
			Point point = new Point(num1,num2);
			System.out.println("x:"+point.getX()+" y:"+point.getY());
			return point;
		}
		else {
			System.out.println("wrong input");
			return null;
		}
		
	}
	public Point getPoint(double x,double y) {
		return new Point(x,y);
	}
	public static void main(String[] args) throws NullPointerException{
		Scanner scanner = new Scanner(System.in);
		String location = scanner.nextLine();
		Point point = Point.parse(location);
	}

}
