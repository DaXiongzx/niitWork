package ZhangXiao.niit.day04;

public class Question {
	private int no;
	private String message;
	private int choice;
	
	public int getNo() {
		return no;
	}
	public Question(int no, String message, int choice) {
		super();
		this.no = no;
		this.message = message;
		this.choice = choice;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getChoice() {
		return choice;
	}
	public void setChoice(int choice) {
		this.choice = choice;
	}
	public void printQuestion() {
		System.out.println("printQuestion....");
	}
	public boolean isAnswerRrite() {
		return false;
	}

}
class oneQuestion extends Question{
	private int answer;
	public oneQuestion(int no, String message, int choice,int answer) {
		super(no, message, choice);
		this.answer =answer;
		// TODO Auto-generated constructor stub
	}

	public int getAnswer() {
		return answer;
	}
	public void setAnswer(int answer) {
		this.answer = answer;
	}
	
	public boolean isAnswerRrite() {
		return true;
	}
}
class moreQuestion extends Question{
	private int answer;
	public moreQuestion(int no, String message, int choice,int answer) {
		super(no, message, choice);
		this.answer =answer;
		// TODO Auto-generated constructor stub
	}

	public int getAnswer() {
		return answer;
	}
	public void setAnswer(int answer) {
		this.answer = answer;
	}
	
	public boolean isAnswerRrite() {
		return true;
	}
}
class paper{
	private Question question;
	private oneQuestion onequestion;
	private moreQuestion moreQuestion;
	
	public void dotest() {
		System.out.println("dotest");
	}
	
}