package ZhangXiao.niit.day03;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class DoubleColorBall {
	public HashMap generateRed() {
		HashMap<String,Boolean> map = new HashMap<>();
		String[] array = {"01","02","03","04","05","06","07","08","09"};
		List<String> list = Arrays.asList(array);
		List red = new ArrayList(list);
		for (int i = 10;i<34;i++) {
			red.add(String.valueOf(i));
		}
		int count = 0;
		while (count<33) {
			map.put((String) red.get(count), true);
			count++;
		}
		return map;
	}
	public HashMap generateBlue() {
		HashMap<String,Boolean> map = null;
		List <String> blue = Arrays.asList("01","02","03","04","05","06","07","08","09");
		for (int i = 10;i<17;i++) {
			blue.add(String.valueOf(i));
		}
		//Iterator<String> iterator = blue.iterator();
		int index = 0;
		while (index<33) {
			
			map.put(blue.get(index), true);
		}
		return map;
		
	}
	public List takeRedBall() {
		HashMap<String,Boolean> redMap = generateRed();
		List red = null;
		Set set = redMap.keySet();
		List<String> array = new ArrayList<>(set); 		
		System.out.println('l'+array.toString());
		Random rand = new Random();
		int count = 0;
		while (count<6) {
			System.out.println(count);
			int index = rand.nextInt(32)+1;
			System.out.println("index"+index);
			if (redMap.get(array.get(index))) {
				red.add(array.get(index));
				count++;
				redMap.put(array.get(index),false);
			}
		}
		return red;
	}

}
