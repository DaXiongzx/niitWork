package ZhangXiao.niit.day03;

import java.util.ArrayList;
import java.util.List;

public class FindStrPosition {
	public List findPosition(String str,char c) {
		List <Integer> list = new ArrayList<>();
		for(int index = 0;index<str.length();index++) {
			if(str.charAt(index)==c)
				list.add(index);
		}
		return list;
	}

}
