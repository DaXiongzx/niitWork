package ZhangXiao.niit.day03;

public class En_13 {
	public int caculate13(String str) {
		int oSum = 0;
		int tSum = 0;
		int index = 0;
		while (index<str.length()) {
			if (index%2==1) {
				tSum+=Integer.parseInt(String.valueOf(str.charAt(index)));
			}
			else {
				oSum+=Integer.parseInt(String.valueOf(str.charAt(index)));
			}
		}
		int sum = oSum+tSum*3;
		int result1 = sum%10;
		int result2 = 10-result1;
		return result2%10;
	}

}
