package ZhangXiao.niit.day02;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class test {
		public static void main(String[] args) {
			ConfirmCode confirmCode = new ConfirmCode();
			String str = confirmCode.generateString();
			List<Integer> num = confirmCode.generateNum();
			System.out.print(str);
			Iterator<Integer> iterator = num.iterator();
			while (iterator.hasNext()) {
				System.out.print(iterator.next());
			}
		}

}
