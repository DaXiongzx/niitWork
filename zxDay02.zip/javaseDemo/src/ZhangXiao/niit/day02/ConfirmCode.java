package ZhangXiao.niit.day02;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ConfirmCode {
	public String generateString() {
		Random rand = new Random();
		int num1 = rand.nextInt(26)+65;
		char str1 = (char)num1;
		int num2 = rand.nextInt(26)+97;
		char str2 = (char)num2;
		String str = String.valueOf(str1)+String.valueOf(str2);
		return str;	
	}
	public List generateNum() {
		Random rand = new Random();
		int num1 = rand.nextInt(10)+0;
		int num2 = rand.nextInt(10)+0;
		List<Integer> num = new ArrayList<Integer>();
		num.add(num1);
		num.add(num2);
		return num;
	}

}
