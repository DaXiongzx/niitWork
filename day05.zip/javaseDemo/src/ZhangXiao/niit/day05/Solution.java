package ZhangXiao.niit.day05;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Solution {
	public static void getSolution(String str,Map map) {
		char []strs = str.toCharArray();
		Set<Character> set = new HashSet<>();
		for(char ch : strs) {//��ʼ��set
			if(set.contains(ch))
				continue;
			else
				set.add(ch);
		}
		for(Character key:set) //��ʼ��map
			map.put(key, 0);
		for(char ch:strs) {
			int value = (int) map.get(ch);
			map.put(ch, value+1);
		}
		
	}
	public static void main(String[] args) {
		String str = "daxiongzzzxx";
		Map<Character,Integer> map = new HashMap<>();
		getSolution(str,map);
		System.out.println(map);
	}

}
